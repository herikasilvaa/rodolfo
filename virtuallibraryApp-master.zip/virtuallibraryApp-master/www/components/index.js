window.onload = ()=>{
    const url = 'https://profrodolfo.com.br/biblioteca/livro.php';
    const insert = document.querySelector('.dados');

    function ExibirAcervo(){
         fetch(url)
        .then(resposta => {
            return resposta.json();
        })
        .then((json)=>{        
            for(i = 0; i < json.length; i++){
            		insert.innerHTML+= `
                        <div class="productBox">
                            <img src="${json[i].capa}">
                            <h2>${json[i].titulo}</h2>
                        </div>
                	`;
            }
        }).catch();
    }
        ExibirAcervo();
}

let usuario = JSON.parse(localStorage.usuario);
let perfil = document.getElementById('perfil');

let dados = "<h3>"+usuario.nome+"</h3>";
dados += '<imr scr="'+usuario.perfil+'" height="100px">';
perfil.innerHTML = dados;

let sair = document.getElementById('sair');
sair.addEventListener('click', function(){
    localStorage.removeItem('usuario');
    window.location.replace('index.html');
});

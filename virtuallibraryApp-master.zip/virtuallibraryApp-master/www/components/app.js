    var form = document.querySelector('#entrar');
    var login = document.querySelector('#login');    
    var senha = document.querySelector('#senha');

     form.addEventListener('click', ()=>{
        var formData = new FormData();
        formData.append('login', `${login.value}`);
        formData.append('senha', `${senha.value}`);

        fetch('https://profrodolfo.com.br/biblioteca/usuario.php',
            {
                body: formData,
                method: "post",
                mode: 'cors',
                cache: 'default'
            })  .then(response => {response.json()
              .then(data => {
                console.log(data);
              if(data.erro){
                    alert("Usuário e/ou senha inválidos!");
                }else{
                  alert(data.dados.nome);
                  localStorage.setItem('usuario', JSON.stringify(data.dados));
                  location.replace('acervo.html');
                }
            })
          });
      });  

      function Verifica(){
        let user = localStorage.usuario;
        if(!user){
          location.replace('index.html');
        }else{
          location.replace('acervo.html');
        }
      }